package cl.goviedo.usermanagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsermanagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsermanagmentApplication.class, args);
	}

}
