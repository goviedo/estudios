module.exports = {
  singleQuote: true,
  printWidth: 120,
};
